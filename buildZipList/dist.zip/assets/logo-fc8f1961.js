const o="/assets/logo-ae2919c0.svg";export{o as l};
