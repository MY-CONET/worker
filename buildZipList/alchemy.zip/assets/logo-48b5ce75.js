const o="/assets/logo-088cf5b8.svg";export{o as l};
